import React from 'react';

const Header = () => {
    return (
        <header className="container">
            <h1>React Axios Example</h1>
        </header>
    )
}

export default Header;