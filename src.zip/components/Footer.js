import React from 'react';

const Footer = () => {
    return (
        <footer className="container">
            <small>&copy; This is a sample Footer</small>
        </footer>
    )
}

export default Footer;